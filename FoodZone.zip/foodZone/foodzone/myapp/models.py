from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
# from django.contrib.auth import get_user_model
# User = get_user_model()


# Create your models here.


class Food(models.Model):
    
    dish_name= models.CharField(max_length=150)
    description = models.CharField(max_length=100)
    type = models.CharField(max_length=250)
    created_by = models.CharField(max_length=100)
    ingredients = models.CharField(max_length=50)
    calories = models.CharField(max_length=50)
    price= models.CharField(max_length=50)
    image = models.ImageField(default=True)
    # image1 = models.ImageField(default=True)
    # image2 = models.ImageField(default=True)
    # image3= models.ImageField(default=True)
    # image4 = models.ImageField(default=True)


    
    def __str__(self):
        return self.dish_name
    


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    # addition of custom fields here, e.g.
    phone_number = models.CharField(max_length=20)
    address = models.CharField(max_length=255)

    def __str__(self):
        return self.user
    

# To implement a cart function, you'll need to create additional models to store this information. Here are a few options:

# Create a Cart model that has a foreign key to the User model and a many-to-many field to the Food model. This will allow you to store multiple food items in a single cart.

# Create a CartItem model that has foreign keys to the Cart model and the Food model, as well as a field to store the quantity of each food item in the cart.

# Create an Order model that has a foreign key to the User model and a many-to-many field to the Food model. This will allow you to store multiple food items in a single order.

# class Cart(models.Model):
#     user = models.OneToOneField(User, on_delete = models.CASCADE)

#     foods = models.ManyToManyField(Food, through='CartItem')

# class CartItem(models.Model):
#     Cart = models.ForeignKey(Cart, on_delete=models.CASCADE)

#     food = models.ForeignKey(Food, on_delete=models.CASCADE)

#     quantity = models.IntegerField(default=0)

# copo from lava nya s project.......

class Category(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name
    
class Dish(models.Model):
    image = models.FileField(upload_to='dish/',blank=True,null=True)
    name = models.CharField(max_length=100,null=False,blank=False)
    category = models.ForeignKey(Category,related_name='dishes',on_delete=models.CASCADE,default=False,null=True)
    ingredients = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
       

    def __str__(self):
        return self.name
    

class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f'cart {self.id} - {self.user.username}'


class Cartitem(models.Model):
    image=models.FileField(upload_to='cart/',blank=True, null=True)
    cart = models.ForeignKey(Cart,related_name='dishes', on_delete = models.CASCADE)
    dish = models.ForeignKey(Dish, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f'{self.quantity} x {self.dish.name} in cart {self.cart.user.username}'
    



