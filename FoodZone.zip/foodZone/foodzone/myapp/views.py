from django.shortcuts import render,HttpResponse,redirect,get_object_or_404,reverse
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login,logout,authenticate
from django.contrib import auth
from django.db.models import Q
from .models import *
from django.contrib import messages
import stripe
from django.http import HttpResponseBadRequest

# create your view here

def home(request):
    return render(request,'home.html')



def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)
            return redirect('home')
        # else:
        #     return redirect('login')

    else:
            return render(request,'login.html')
    
def signup(request):
    frm = UserCreationForm()
    if request.method == 'POST':
         frm = UserCreationForm(request.POST)
         if frm.is_valid():
              frm.save()
              return redirect('/')
    return render(request,'signup.html',{'fm':frm})

def header(request):
     return render(request,'header.html')

def cart(request):
     return HttpResponse("<h1>This is cart area </h1>")

def search(request):
     return HttpResponse("<h1>This is search area </h1>")

def account(request):
     return HttpResponse("<h1>This is account area </h1>")

def logout(request):
     # logout(request)
     return redirect('login')


def navbar(request):
     return render(request,'navbar.html')

def footer(request):
     return render(request,'footer.html')

def aboutus(request):
     return render(request,'aboutus.html')
def menu(request):
     return render(request,'menu.html')

def gallery(request):
     return render(request,'gallery.html')


def menu1(request):
     return render(request,'menu1.html')

def review(request):
     return render(request,'review.html')

def blog(request):
     return render(request,'blog.html')

def contactus(request):
     return render(request,'contactus.html')

def contactus1(request):
     return render(request,'contactus1.html')

def orderonline(request):
     return render(request,'orderonline.html')

def food(request):
     query = request.GET.get('q')
     if query:
          foods = Food.objects.filter(dish_name__icontains=query).order_by('dish_name')

     else:
          foods = Food.objects.all().order_by('dish_name')

     context = {
          'foods':foods,
          'query':query
     }

     return render(request,'food.html',context)


def search(request):
     query = request.GET.get('q')
     if query:
          food = Food.objects.filter(dish_name__icontains=query).order_by('dish_name')

     else:
          food = Food.objects.all().order_by('dish_name')

     context = {
          'food':food,
          'query':query
     }

     return render(request,'food.html',context)

def test(request):
     return render(request,'test1.html')


def searcha(request):
     query = request.GET.get('search')
     if query:
          food1 = Food.objects.filter(dish_name__icontains=query).order_by('dish_name')

     else:
          food1 = Food.objects.all().order_by('dish_name')

     context = {
          'food':food1,
          'query':query
     }

     return render(request,'food.html',context)

def dish(request):
    categories = Category.objects.all()
    dishes = Dish.objects.all()  # Fetch all products to display
    return render(request, 'order.html', {'categories': categories, 'dishes': dishes})

def cart(request):
     cart, created = Cart.objects.get_or_create(user=request.user)
     cart_items =  cart.dishes.all()
     total_price = sum(cart_item.quantity * cart_item.dish.price for cart_item in cart_items )
     return render(request,'cart.html',{'cart_items':cart_items,'total_price':total_price,'cart':cart})
def add_to_cart(request,dish_id):
     cart, created = Cart.objects.get_or_create(user=request.user)
     dish = Dish.objects.get(id=dish_id)
     cart_item, created = Cartitem.objects.get_or_create(cart=cart,dish=dish)

     cart_item.quantity += 1
     cart_item.save()
     messages.success(request, f"{dish.name} Added in your cart.")
     return redirect('cart')


def remove_from_cart(request, cart_item_id):
     cart_item = get_object_or_404(Cartitem, id = cart_item_id)
     dish_name = cart_item.dish.name
     cart_item.delete()
     messages.success(request, f"{dish_name}  removed  from your cart.")
     return redirect('cart')



def checkout(request):
     if request.method == 'POST':
        pass
     return render(request,'checkout.html')


import logging
stripe.api_key = "sk_test_51PiV2tSHhsNN23Z1uaemlRWp0JTkiuLQk42Jib5ZT858F2UEPKGdoSnSi69XiBTL0TzTuZb3j44vCrQc647smSn000I8nEflJn"

def create_checkout_session(request):
    if not request.user.is_authenticated:
        return redirect('login')  

    cart, created = Cart.objects.get_or_create(user=request.user)
    cart_items = Cartitem.objects.filter(cart=cart)  
    total_price = 0

    for cart_item in cart_items:
        unit_price_in_paise = int(cart_item.dish.price * 100)
        item_total_amount = unit_price_in_paise * cart_item.quantity
        total_price += item_total_amount
    print(f"Total price of the cart: {total_price} paise")
    if request.method == 'POST':
        try:
            checkout_session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[{
                    'price_data': {
                        'currency': 'inr',
                        'unit_amount': total_price, 
                        'product_data': {
                            'name': "Cart Total",  
                        },
                    },
                    'quantity': 1, 
                }],
                mode='payment',
                success_url=request.build_absolute_uri('/success/'),
                cancel_url=request.build_absolute_uri('/cancel/'),
            )
            return redirect(checkout_session.url, code=303)
        except stripe.error.StripeError as e:
            return HttpResponseBadRequest(f"Error creating checkout session: {str(e)}")
    else:
        return HttpResponseBadRequest("Invalid request method.")
def success(request):
    return render(request, 'checkout.html', {"payment_status": "success_url"})

def cancel(request):
    return render(request, 'cancel.html', {"payment_status": "cancel_url"})



def example_function(**kwargs):
  try:
    stripe.PaymentIntent.create(**kwargs)
  except stripe.error.CardError as e:
    logging.error("A payment error occurred: {}".format(e.user_message))
  except stripe.error.InvalidRequestError:
    logging.error("An invalid request occurred.")
  except Exception:
    logging.error("Another problem occurred, maybe unrelated to Stripe.")
  else:
    logging.info("No error.")





def success(request):
    return render(request,'success.html',{"payment_status":"success_url"})

import logging
stripe.api_key = "sk_test_51Q25LFRtgfLsSTRpvkovpdQoziuukyAYBNrxw6GaQo0sJJDcx0AMojZ0sOsorQfPDMXlWoW0WmVVuibj2eNaFqnf007TvBBhSc"
