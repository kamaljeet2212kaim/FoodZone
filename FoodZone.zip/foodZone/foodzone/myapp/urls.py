
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from .views import *

urlpatterns = [
    path("",login,name='login'),
    path("home/",home,name='home'),
    path("signup/",signup,name='signup'),
    path('header/',header,name='header'),
    #
    path('search/',search,name='search'),
    path('account/',account,name='account'),
    path('logout/',logout,name='logout'),
    path('cart/',cart,name='cart'), 
    # 
    path('navbar/',navbar,name='navbar'),
    path('footer/',footer,name='footer'),
    path('aboutus/',aboutus,name='aboutus'),
    path('menu/',menu,name='menu'),
    path('gallery/',gallery,name='gallery'),
    path('menu1/',menu1,name='menu1'),
    path('review/',review,name='review'),
    path('blog/',blog,name='blog'),
    path('contactus/',contactus,name='contactus'),
    path('contactus1/',contactus1,name='contactus1'),
    path('orderonline/',orderonline,name='orderonline'),
    path('food/',food,name='food'),
    path('test/',test,name='test'),
    path('searcha/',searcha,name='searcha'),

    # copying urls from nikhil bro's  file.....
    # path('product/', product, name="product"),
    # path('product/<int:product_id>/', product_detail, name="product_detail"),
    # path('add_to_cart/<int:product_id>/', add_to_cart, name='add_to_cart'),
    # path('add_cart/<int:product_id>/', add_cart, name='add_cart'),
    # path('remove_from_cart/<int:cart_item_id>/', remove_from_cart, name='remove_from_cart'),
    path('cart/', cart, name='cart'),
    path('dish/',dish,name='dish'),
    # path('cart/adjust/<int:cart_item_id>/<str:action>/', adjust_cart_item, name='adjust_cart_item'),
    #Ending from nikhil bro's file  .....
    path('add_to_cart/<int:dish_id>/', add_to_cart, name = 'add_to_cart'),
    path('remove_from_cart/<int:cart_item_id>/', remove_from_cart, name = 'remove_from_cart'),
    path('checkout/',checkout,name='checkout'),
    path('cancel/',cancel,name='cancel'),
    path('success/',success,name='success'),
    path('create-checkout-session/',create_checkout_session,name='create-checkout-session'),
    
]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)